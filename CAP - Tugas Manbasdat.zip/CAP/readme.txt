Ini Project Semester 3
Client : Cahaya Abadi Perkasa
CodeName : PeTakon
Deadline 21 Desember 2019
Pameran Januari 2020
Goodluck

Here we go, Bismillahirrahmaanirrahiim.